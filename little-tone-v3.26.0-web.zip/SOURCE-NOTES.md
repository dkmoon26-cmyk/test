게임 실행: index.html과 assets를 함께 사용하세요.
전체 실행 소스는 app-*.js·boot-*.js·style-*.css이며, 커스텀 제작 편집 원본은 source/custom-workshop에 있습니다.
고해상도 편집용 이미지와 빌드·검사 도구는 GitHub의 validation-v3.26.0에서 확인할 수 있습니다.
저장 형식 31 · 기존 버전 저장을 불러올 수 있습니다. 업데이트 전 저장 파일을 백업하세요.
