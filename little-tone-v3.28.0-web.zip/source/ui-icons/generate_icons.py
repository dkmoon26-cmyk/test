import math,os,json
INK='#65513a';TAN='#e8cf91';CREAM='#fff4d6';GREEN='#698466';DGREEN='#355f51';SAGE='#b9c8a0';WOOD='#b0784c';GOLD='#efbc42';RED='#d86a5a';SKY='#7fa6b8';CLOUD='#f4f1e6'
def f(n): return ('%.2f'%n).rstrip('0').rstrip('.')
def gear():
    pts=[]
    n=8
    for i in range(n):
        a=2*math.pi*i/n
        for da,r in ((-0.20,11.5),(-0.12,15),(0.12,15),(0.20,11.5)):
            pts.append((20+r*math.cos(a+da),20+r*math.sin(a+da)))
    return 'M'+'L'.join(f'{f(x)} {f(y)}' for x,y in pts)+'Z'
def star(cx,cy,R,r):
    pts=[]
    for i in range(10):
        a=-math.pi/2+i*math.pi/5; rr=R if i%2==0 else r
        pts.append((cx+rr*math.cos(a),cy+rr*math.sin(a)))
    return 'M'+'L'.join(f'{f(x)} {f(y)}' for x,y in pts)+'Z'
rays=''.join(f'M{f(20+11*math.cos(a))} {f(20+11*math.sin(a))}L{f(20+15*math.cos(a))} {f(20+15*math.sin(a))}' for a in [i*math.pi/4 for i in range(8)])
UI={
'pause':f'<rect x="9" y="8" width="8" height="24" rx="2.5" fill="{TAN}"/><rect x="23" y="8" width="8" height="24" rx="2.5" fill="{TAN}"/>',
'play':f'<path d="M13 8.5c0-1.6 1.7-2.5 3-1.7l16 10.7c1.2.8 1.2 2.6 0 3.4L16 31.6c-1.3.9-3 0-3-1.7z" fill="{GREEN}"/>',
'fast':f'<path d="M6 10c0-1.4 1.5-2.1 2.6-1.4l11 9.6c.9.8.9 2.2 0 3L8.6 30.8C7.5 31.6 6 30.9 6 29.5z" fill="{TAN}"/><path d="M21 10c0-1.4 1.5-2.1 2.6-1.4l11 9.6c.9.8.9 2.2 0 3l-11 9.6c-1.1.8-2.6.1-2.6-1.3z" fill="{TAN}"/>',
'gear':f'<path d="{gear()}" fill="{TAN}"/><circle cx="20" cy="20" r="5" fill="{CREAM}"/>',
'zoom-in':f'<path d="M25 25l8 8" stroke="{WOOD}" stroke-width="4.2" fill="none"/><path d="M25 25l8 8" stroke-width="1.6" fill="none" opacity="0"/><circle cx="17" cy="17" r="10.5" fill="{CREAM}"/><path d="M17 11.5v11M11.5 17h11" fill="none" stroke-width="2.4"/>',
'zoom-out':f'<path d="M25 25l8 8" stroke="{WOOD}" stroke-width="4.2" fill="none"/><circle cx="17" cy="17" r="10.5" fill="{CREAM}"/><path d="M11.5 17h11" fill="none" stroke-width="2.4"/>',
'locate':f'<circle cx="20" cy="20" r="10" fill="{CREAM}"/><circle cx="20" cy="20" r="3.4" fill="{GREEN}"/><path d="M20 4v7M20 29v7M4 20h7M29 20h7" fill="none" stroke-width="2.2"/>',
'sun':f'<path d="{rays}" fill="none" stroke="{GOLD}" stroke-width="3"/><path d="{rays}" fill="none" stroke-width="0"/><circle cx="20" cy="20" r="7.5" fill="{GOLD}"/>',
'cloud':f'<path d="M11.5 29h17.5a6 6 0 0 0 .9-11.9A8.5 8.5 0 0 0 13.6 15.5 6.8 6.8 0 0 0 11.5 29z" fill="{CLOUD}"/>',
'rain':f'<path d="M11.5 24h17.5a5.5 5.5 0 0 0 .9-10.9A8 8 0 0 0 13.6 11.6 6.3 6.3 0 0 0 11.5 24z" fill="{CLOUD}"/><path d="M14 28.5l-1.6 4.5M21 28.5l-1.6 4.5M28 28.5l-1.6 4.5" fill="none" stroke="{SKY}" stroke-width="2.6"/>',
'coin':f'<circle cx="20" cy="20" r="13.5" fill="{GOLD}"/><circle cx="20" cy="20" r="9.4" fill="none" stroke-width="1.2"/><path d="M14.5 15.5a7 7 0 0 1 5-3" fill="none" stroke="#fff4d6" stroke-width="1.8" opacity=".9"/>',
'star':f'<path d="{star(20,21,15,6.6)}" fill="{GOLD}"/>',
'person':f'<path d="M7.5 34c.9-8.2 6-11.5 12.5-11.5S31.6 25.8 32.5 34z" fill="{SAGE}"/><circle cx="20" cy="13.5" r="6.8" fill="{CREAM}"/>',
'calendar':f'<rect x="6.5" y="8.5" width="27" height="24" rx="3.5" fill="{CREAM}"/><path d="M6.5 12a3.5 3.5 0 0 1 3.5-3.5h20a3.5 3.5 0 0 1 3.5 3.5v5h-27z" fill="{GREEN}"/><path d="M13 5.5v6M27 5.5v6" fill="none" stroke-width="2.4"/><path d="M12.5 23h2.6M18.7 23h2.6M24.9 23h2.6M12.5 28h2.6M18.7 28h2.6" fill="none" stroke-width="2"/>',
'fullscreen':f'<rect x="8" y="8" width="24" height="24" rx="4" fill="{CREAM}"/><path d="M6 14V6h8M26 6h8v8M34 26v8h-8M14 34H6v-8" fill="none" stroke-width="2.6"/>',
'close':f'<path d="M11 11l18 18M29 11L11 29" fill="none" stroke-width="3.6"/>',
'check':f'<path d="M9 21l8 8L31 11" fill="none" stroke="{DGREEN}" stroke-width="4"/>',
}
BUB='<path d="M5 13.5A9.5 9.5 0 0 1 14.500 4h11A9.500 9.500 0 0 1 35 13.500v7A9.500 9.500 0 0 1 25.500 30H24l-4 6-4-6h-1.500A9.500 9.500 0 0 1 5 20.500z" fill="#fff4d6"/>'
def em(inner): return BUB+inner
EM={
'love':em(f'<path d="M20 25.500c-7-4.600-8.500-8-8.500-10.600 0-2.700 2-4.500 4.400-4.500 1.700 0 3.200.9 4.100 2.400.9-1.500 2.400-2.400 4.100-2.400 2.400 0 4.400 1.800 4.400 4.500 0 2.600-1.500 6-8.500 10.600z" fill="{RED}"/>'),
'delight':em(f'<path d="M20 8.500l2.600 6.900 6.900 2.600-6.900 2.600L20 27.500l-2.600-6.900L10.500 18l6.900-2.600z" fill="{GOLD}"/>'),
'think':em(f'<path d="M15 14a5 5 0 1 1 7.200 4.400c-1.400.7-2.200 1.700-2.200 3.100" fill="none" stroke-width="3"/><circle cx="20" cy="26" r="1.9" fill="{INK}" stroke="none"/>'),
'surprise':em(f'<path d="M20 8.500v11" fill="none" stroke-width="3.600"/><circle cx="20" cy="25.200" r="2.100" fill="{INK}" stroke="none"/>'),
'angry':em(f'<path d="M11.500 12.500q5 0 6-5M28.500 12.500q-5 0-6-5M11.500 22.500q5 0 6 5M28.500 22.500q-5 0-6 5" fill="none" stroke="#c05040" stroke-width="2.800"/>'),
'bored':em(f'<path d="M11.500 12h7l-7 7.500h7" fill="none" stroke-width="2.600"/><path d="M22 15.500h8.500L22 25h8.500" fill="none" stroke-width="2.600"/>'),
'music':em(f'<ellipse cx="16" cy="23.500" rx="3.600" ry="2.800" fill="{GREEN}" transform="rotate(-18 16 23.500)"/><path d="M19.300 22.500V9.500l8.700 3v5l-8.700-3" fill="{GREEN}"/>'),
'sad':em(f'<path d="M20 8.5c3.6 4.7 6.2 8.1 6.2 11.1a6.2 6.2 0 0 1-12.4 0c0-3 2.6-6.4 6.2-11.1z" fill="{SKY}"/><path d="M17.2 20.5a3 3 0 0 0 2.2 2.6" fill="none" stroke="#fff4d6" stroke-width="1.4"/>'),
'pay':em(f'<circle cx="20" cy="17.500" r="9" fill="{GOLD}"/><circle cx="20" cy="17.500" r="6" fill="none" stroke-width="1.200"/>'),
}
def sym(id,body,extra=''):
    return f'<symbol id="{id}" viewBox="0 0 40 40"><g fill="none" stroke="{INK}" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">{body}</g></symbol>'
os.makedirs('ui',exist_ok=True);
def single(body): return f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 40 40" width="40" height="40" fill="none" stroke="{INK}" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">{body}</svg>\n'
for k,v in UI.items(): open(f'ui/{k}.svg','w').write(single(v))
open('ui-icons.svg','w').write('<svg xmlns="http://www.w3.org/2000/svg" style="display:none">'+''.join(sym('ui-'+k,v) for k,v in UI.items())+'</svg>\n')
cells=''.join(f'<div class="c"><svg viewBox="0 0 40 40" width="88" height="88" fill="none" stroke="{INK}" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">{v}</svg><i>{k}</i></div>' for k,v in {**UI}.items())
cells2=''.join(f'<div class="c"><svg viewBox="0 0 40 40" width="88" height="88" fill="none" stroke="{INK}" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">{v}</svg><i>{k}</i></div>' for k,v in EM.items())
small=''.join(f'<svg viewBox="0 0 40 40" width="24" height="24" fill="none" stroke="{INK}" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">{v}</svg>' for v in list(UI.values())+list(EM.values()))
open('preview.html','w').write(f'<body style="margin:0;background:#fbf2dc;font:11px sans-serif;color:#352e25"><style>.g{{display:flex;flex-wrap:wrap;gap:6px;padding:12px}}.c{{width:100px;text-align:center}}.c i{{display:block;font-style:normal}}</style><div class=g>{cells}</div><div class=g>{cells2}</div><div class=g style="gap:8px;background:#355f51">{small}</div></body>')
print(len(UI),len(EM))
