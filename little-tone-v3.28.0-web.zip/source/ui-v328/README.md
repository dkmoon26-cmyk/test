# 회녹색 UI · v3.28.0

업로드된 v3.27.0 UI팩을 기준으로 변경했습니다. theme.css는 배포 CSS의 마지막에 결합된 전체 공통 테마입니다. fonts.css는 Wanted Sans Variable을 서브셋한 Little Tone UI의 문자별 로딩 선언입니다. functions.js는 배포 app의 변경된 함수 원본 참조이며 독립 실행 파일이 아닙니다.

전체 배포 소스는 루트 app-*.js, style-*.css, index.html, boot-*.js입니다. 이미지와 UI 아이콘 원본은 기존 assets/ 및 source/에 있습니다. 수정 뒤 tools/update-hashes.py를 실행하면 파일명과 HTML 참조, DEPLOY-MANIFEST.json을 갱신합니다.

Wanted Sans의 상업적 사용과 재배포는 SIL OFL 1.1에 따라 허용됩니다. 저작권과 라이선스 전문은 assets/OFL-WantedSans.txt에 포함합니다. 서브셋 글꼴의 내부 이름은 Little Tone UI로 변경했습니다. 기본 UI 문자(약 89KB)를 우선 불러오고, 나머지 문자(약 1.2MB)는 해당 글자를 사용할 때만 로딩합니다. 외부 CDN에 의존하지 않습니다.

원본: https://github.com/wanteddev/wanted-sans/tree/main/packages/wanted-sans

업로드 파일의 매장 수용 인원, 손님 이동, 미션 안내 및 원가 계산 변경을 유지했습니다. 이 UI 패치는 주문 방식이나 악기 가격을 바꾸지 않습니다. 원가 기록이 없는 기존 저장의 첫 정산은 오늘 수지를 표시합니다. 이후 정산은 원가·운영비를 제외한 오늘 이익과 재고·시설 구입 지출을 구분합니다. 유효한 이익 기록은 정산 화면에서 저장 후 불러와도 보존합니다.
