// Editable reference: these functions are compiled inside app-*.js.

function compactMoney(n){if(!Number.isFinite(n))return '0원';const a=Math.abs(n),sign=n<0?'-':'';const fmt=x=>new Intl.NumberFormat('ko-KR',{maximumFractionDigits:1}).format(x);return a>=1e8?sign+fmt(a/1e8)+'억 원':a>=1e4?sign+fmt(a/1e4)+'만 원':Math.round(n).toLocaleString('ko-KR')+'원';}

function before24ShowSettlement() {
  for(const id of ['missionDialog','dismissConfirm','staffSettings','staffManagement'])$(id).close();
  const r = S.settlement;
  if (!r) return;
  $('management').close();
  $('modal').close();
  $('settlementTitle').textContent = '오늘 영업 마감';
  $('dailyIncome').textContent = '+' + compactMoney(r.income);
  $('dailyExpense').textContent = '−' + compactMoney(r.expenses);
  $('dailyNet').textContent = (r.net >= 0 ? '+' : '−') + compactMoney(Math.abs(r.net));
  {const labels=document.querySelectorAll('#settlement .settlement-row > span'),hasProfit=Number.isFinite(r.profit),net=$('dailyNet');
   if(labels.length>=3){labels[1].textContent=hasProfit?'원가·운영비':'오늘 지출';labels[2].textContent=hasProfit?'오늘 이익':'오늘 수지';}
   if(hasProfit){$('dailyExpense').textContent='−'+compactMoney(r.cogs+r.operating);net.textContent=(r.profit>=0?'+':'−')+compactMoney(Math.abs(r.profit));}
   net.closest('.settlement-row').classList.toggle('loss',(hasProfit?r.profit:r.net)<0);
   let note=$('dailyInvest');if(!note){note=document.createElement('p');note.id='dailyInvest';note.className='settlement-note';net.closest('.settlement-row').after(note);}
   note.textContent=hasProfit&&r.invest>0?'재고·시설 구입 −'+compactMoney(r.invest):'';note.hidden=!note.textContent;}
  $('nextDay').textContent=endingPending()?'엔딩 보기 →':'다음 날 준비하기 →';
  if (!$('settlement').open) $('settlement').showModal();
}

function showSettlement(){before24ShowSettlement();const stamp=document.querySelector('#settlement>.eyebrow');if(stamp){const d=calendar24(S.settlement?.day??S.day);stamp.textContent=d.year+'년차 · '+d.seasonName+' '+d.month+'개월 '+['월','화','수','목','금','토','일'][d.weekday];}if(endingPending())$('nextDay').textContent='1주년 보기 →';let el=$('tomorrow24');if(!el){el=document.createElement('p');el.id='tomorrow24';$('nextDay').before(el);}const next=ensureCalendar24().next,c=calendar24(next.day);el.textContent='내일 · '+c.seasonName+' '+c.month+'개월 '+['월','화','수','목','금','토','일'][c.weekday]+' · '+Weather24[next.weather].name+(next.event==='none'?'':' · '+Events24[next.event].name);}

function refreshStockFooter(){
 const footer=$('stockFooter');if(!footer||tab!=='stock')return;
 const rows=[...document.querySelectorAll('#panel .product-order:not(.locked-product)')].filter(row=>!row.hidden);
 if(!rows.length){footer.hidden=true;return;}footer.hidden=false;
 let row=rows.find(row=>+row.dataset.productRow===selectedProduct)??rows[0];selectedProduct=+row.dataset.productRow;
 for(const r of rows)r.classList.toggle('selected-product',r===row);
 const i=selectedProduct,n=purchaseQuantity(i),total=purchaseCost(i)*n;
 const input=row.querySelector('[data-quantity-input]'),valid=!input||input.value!==''&&Number.isInteger(Number(input.value))&&+input.value>=1&&+input.value<=999;
 const signature=[i,n,total,S.money,valid,setupReserve(-1)].join('|');if(footer.dataset.state===signature)return;footer.dataset.state=signature;
 footer.innerHTML=`<div><small>${products[i].name} · ${n}개</small><strong>합계 ${compactMoney(total)}</strong></div><button class="primary" data-order="${i}" ${!valid||S.money<total+setupReserve(-1)?'disabled':''}>주문하기</button>`;
}

function drawCustomModel(){if(!workshopDraft?.options?.design26)return before26DrawCustomModel();const el=$('customModel');if(!el)return;const c=el.getContext('2d'),W=el.width,H=el.height,angle=workshopAngle*Math.PI/180,rear=Math.cos(angle)<0,im=customTexture(workshopDraft,rear);c.clearRect(0,0,W,H);const bg=c.createLinearGradient(0,0,0,H);bg.addColorStop(0,'#eef2e9');bg.addColorStop(1,'#d5dfce');c.fillStyle=bg;c.fillRect(0,0,W,H);if(!im)return;const h=H*.84,w=h*im.width/im.height,squeeze=Math.max(.035,Math.abs(Math.cos(angle))),x=W/2,y=H*.90;preview26={x,y,w,h,squeeze,rear,W,H};c.fillStyle='#41382a14';c.beginPath();c.ellipse(x,y+8,w*.45,10,0,0,Math.PI*2);c.fill();c.save();c.translate(x,y);c.scale(squeeze,1);c.drawImage(im,-w/2,-h,w,h);if(workshopTab26==='motifs'&&selectedMark26>=0){const m=workshopDraft.options.design26[rear?'back':'front'][selectedMark26];if(m){const b=markBox26(workshopDraft.base,m,rear);c.save();c.translate(-w/2+m.x*w,-h+m.y*h);c.rotate(m.rotation*Math.PI/180);c.strokeStyle='#477c60';c.lineWidth=2;c.setLineDash([6,4]);c.strokeRect(-b.w*w/2,-b.h*h/2,b.w*w,b.h*h);c.setLineDash([]);c.fillStyle='#eef2e9';for(const sx of[-1,1])for(const sy of[-1,1]){c.fillRect(sx*b.w*w/2-4,sy*b.h*h/2-4,8,8);c.strokeRect(sx*b.w*w/2-4,sy*b.h*h/2-4,8,8);}c.restore();}}c.restore();}

function validateExpansionSave(v,s,rules){before25ValidateExpansionSave(v,s,rules);
 // Preserve verified optional profit fields when resuming the settlement screen.
 {const r=v.settlement,q=s.settlement,valid=n=>Number.isFinite(n)&&n>=0&&n<1e15;
 if(q&&r&&['cogs','operating','invest'].every(k=>valid(r[k]))&&Number.isFinite(r.profit)&&Math.abs(r.profit-(q.income-r.cogs-r.operating))<.01&&Math.abs(r.operating-(q.rent+q.wage))<.01&&Math.abs(r.invest-Math.max(0,q.expenses-r.operating))<.01){for(const k of ['cogs','operating','invest','profit'])q[k]=r[k];}}
{const num=x=>Number.isFinite(x)&&x>=0&&x<1e15;if(num(v.ledgerStockValue))s.ledgerStockValue=v.ledgerStockValue;if(num(v.ledgerStockSpend))s.ledgerStockSpend=v.ledgerStockSpend;const w=v.missionWatchLT;if(w&&typeof w==='object'){const o={};for(const lane of ['growth','challenge']){const x=w[lane];if(x&&typeof x.id==='string'&&MissionDefinitions.some(m=>m.id===x.id)&&Number.isInteger(x.progress)&&Number.isInteger(x.day)&&x.day>=1&&x.day<=s.day)o[lane]={id:x.id,progress:x.progress,day:x.day};}s.missionWatchLT=o;}}for(const f of s.furniture)if(f.t===15){const raw=v.furniture.find(q=>q.id===f.id);f.vipModel=raw.vipModel??f.vipSlots?.[0]??null;if(f.vipModel!==null&&(!isVIPProduct(f.vipModel)||products[f.vipModel].unlock>s.stage)||f.vipSlots?.[0]!=null&&f.vipSlots[0]!==f.vipModel)throw Error('명품 진열 모델');}
 const raw=v.vip?.guest,g=s.vip.guest;if(g){for(const[k,def]of Object.entries({budget25:Atelier.profiles[g.profile].budget,spent25:0,purchased25:g.bought?1:0})){const n=raw[k]??def;if(!Number.isSafeInteger(n)||n<0||n>(k==='purchased25'?2:100000000)||k==='budget25'&&n>Atelier.profiles[g.profile].budget)throw Error('VIP 구매 예산');g[k]=n;}g.secondChecked25=raw.secondChecked25===true;if(g.spent25>g.budget25||g.purchased25===2&&!g.bought)throw Error('VIP 구매 횟수');}
 for(const p of s.guests)if(p.decorView25!==undefined){const d=p.decorView25;if(typeof p.decorSeen25!=='boolean'||!d||!Number.isSafeInteger(d.id)||!s.furniture.some(f=>f.id===d.id&&isViewDecor25(f))||!Number.isFinite(d.wait)||d.wait<0||d.wait>2||!Array.isArray(d.resumePath)||d.resumePath.length>64)throw Error('소품 구경');for(const q of d.resumePath)if(!Number.isFinite(q.x)||!Number.isFinite(q.y)||q.x<0||q.y<0||q.x>=Stages[s.stage].w||q.y>=Stages[s.stage].h)throw Error('구경 복귀 경로');}
}
