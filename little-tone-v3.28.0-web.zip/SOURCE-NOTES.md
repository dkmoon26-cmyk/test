게임 실행: index.html과 assets를 함께 사용하세요.
전체 실행 소스는 app-*.js·boot-*.js·style-*.css입니다. source/custom-workshop은 기본 커스텀 모듈이고, source/display-and-custom-v327은 이번 진열대·색상·문양 변경 소스입니다.
새 진열대 고해상도 PNG와 빌드·검사 도구는 GitHub의 validation-v3.27.0에서 확인할 수 있습니다.
저장 형식32 · 이전 버전 저장을 불러올 수 있습니다. 업데이트 전 파일 백업을 권장합니다.

[CSS 원본 규칙 · UI 토큰 정리 이후]
- 지금의 style-*.css 가 UI 스타일의 원본입니다. 색·글자 크기·모서리 값은 파일 맨 앞 :root 의 토큰(--ink, --paper, --green, --fs-*, --r-* 등)을 바꾸거나 var(--토큰)으로 쓰세요.
- source/custom-workshop/style.css 도 같은 토큰으로 맞춰져 있고, 번들 CSS 안에 같은 내용으로 들어 있습니다.
- CSS를 수정한 뒤에는 python3 tools/update-hashes.py 를 실행하세요. 파일명 해시, index.html 링크, DEPLOY-MANIFEST.json 이 자동으로 맞춰집니다. 검사만 하려면 --check.



## v3.28.0 회녹색 UI
전체 공통 테마와 글꼴, 변경 함수의 편집용 참조: source/ui-v328/. 업로드된 UI팩의 게임 규칙을 유지하며 배포 버전은 v3.28.0, 저장 스키마는 32입니다.
