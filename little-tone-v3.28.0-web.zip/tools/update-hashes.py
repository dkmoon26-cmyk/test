#!/usr/bin/env python3
"""CSS·JS 파일을 수정한 뒤 실행하세요.

- style-*.css / app-*.js / boot-*.js 의 파일명을 내용 해시로 갱신합니다 (브라우저 캐시 무효화)
- index.html 안의 참조(CSS 링크, window.GameAppURL, boot 스크립트)를 새 파일명으로 바꿉니다
- DEPLOY-MANIFEST.json 의 path / bytes / sha256 를 실제 파일과 맞춥니다

사용법 (게임 폴더 최상위에서):  python3 tools/update-hashes.py
검사만:                        python3 tools/update-hashes.py --check   (불일치 시 종료코드 1)
"""
import glob
import hashlib
import json
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(ROOT)
CHECK = '--check' in sys.argv
BUNDLES = (('style-', '.css'), ('app-', '.js'), ('boot-', '.js'))


def sha(path):
    with open(path, 'rb') as fh:
        return hashlib.sha256(fh.read()).hexdigest()


problems = []
renames = {}
html = open('index.html', encoding='utf-8').read()
for prefix, ext in BUNDLES:
    found = glob.glob(f'{prefix}*{ext}')
    if len(found) != 1:
        sys.exit(f'{prefix}*{ext} 가 정확히 1개여야 합니다 (현재 {len(found)}개: {found})')
    old = found[0]
    new = f'{prefix}{sha(old)[:12]}{ext}'
    if old == new:
        continue
    problems.append(f'파일명 변경 필요: {old} -> {new}')
    if html.count(old) != 1:
        sys.exit(f'index.html 에서 {old} 참조를 정확히 하나 찾지 못했습니다')
    renames[old] = new
    if not CHECK:
        os.rename(old, new)
        html = html.replace(old, new)
if renames and not CHECK:
    open('index.html', 'w', encoding='utf-8').write(html)

manifest = json.load(open('DEPLOY-MANIFEST.json', encoding='utf-8'))
files = manifest['files']
if not CHECK:
    gone = [e['path'] for e in files if e['path'] not in renames and not os.path.exists(e['path'])]
    for path in gone:
        problems.append(f'삭제된 파일을 매니페스트에서 제거: {path}')
    files[:] = [e for e in files if e['path'] not in gone]
for entry in files:
    if entry['path'] in renames and not CHECK:
        entry['path'] = renames[entry['path']]
    path = entry['path']
    if not os.path.exists(path):
        problems.append(f'매니페스트에 있으나 파일 없음: {path}')
        continue
    size, digest = os.path.getsize(path), sha(path)
    if entry['bytes'] != size or entry['sha256'] != digest:
        problems.append(f'매니페스트 값 갱신: {path}')
        entry['bytes'], entry['sha256'] = size, digest

listed = {e['path'] for e in files}
for path in sorted(glob.glob('**/*', recursive=True)):
    if os.path.isfile(path) and path not in listed and path != 'DEPLOY-MANIFEST.json' \
            and '__pycache__' not in path:
        problems.append(f'매니페스트에 파일 추가: {path}')
        files.append({'path': path, 'bytes': os.path.getsize(path), 'sha256': sha(path)})
files.sort(key=lambda e: e['path'])

for line in problems:
    print(line)
if CHECK:
    print('불일치 있음' if problems else '모두 일치')
    sys.exit(1 if problems else 0)
with open('DEPLOY-MANIFEST.json', 'w', encoding='utf-8') as fh:
    json.dump(manifest, fh, indent=2, ensure_ascii=False)
    fh.write('\n')
print('완료' if problems else '변경 없음')
